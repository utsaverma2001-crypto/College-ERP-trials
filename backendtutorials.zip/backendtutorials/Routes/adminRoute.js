const express= require("express");
const router= express.Router();
const Admins= require('../Models/adminModel');
const {registerVal,loginVal} = require('../validation');
const bcrypt =require("bcrypt");
router.get('/get',async(req,res)=>
{
    Admins.find().then(data=>{
        res.json(data);
    })
});
router.post('/register',async(req,res)=>
{
    const {error}=registerVal(req.body);
    if(error){
        return res.json(error);
    }

    //Admin exists
    const adminExist= await Admins.findOne({email:req.body.email});
    if(adminExist)
    {
        return res.json({message:"admin already exists"});
    }
    //confirm password
    if(req.body.password!==req.body.confirmPassword)
    {
       return res.json({message:"passwords doesnt match"});
    }
  try{
    const salt= await bcrypt.genSalt(7);
    const hashPassword= await bcrypt.hash(req.body.password,salt);


    //storeadminin database
    const adminInput={
        name:req.body.name,
        email:req.body.email,
        password:hashPassword,
        dob:req.body.dob,
        phone:req.body.phone
    };
    const newAdmin = new Admins(adminInput);
    newAdmin.save().then(data=>{
        res.json(data);
    });
  }catch(err){
      return res.json(err);
  }
});

  router.post("/login",async(req,res)=>
  {
      const {error}=loginVal(req.body);
      if(error){
          return res.json(error);
      }
      const adminExist= await Admins.findOne({
          email:req.body.email
      });
      if(!adminExist)
      {
          return false;
      }
      //password matching
      const varified = await bcrypt.compare(req.body.password,adminExist.password);
      if(!varified)
      {
          return false;
      }
      return res.json(adminExist);
      
  })
  

module.exports=router;