const express= require("express");
const router= express.Router();
const Students= require('../Models/studentModel');
const {studentVal,loginVal} = require('../validation');
router.get('/get',async(req,res)=>
{
    Students.find().then(data=>{
        res.json(data);
    })
});
router.post('/register',async(req,res)=>
{
    const {error}=studentVal(req.body);
    if(error){
        return res.json(error);
    }
    //student exist
    const studentExist= await Students.findOne({email:req.body.email});
    if(studentExist)
    {
        return res.json({message:"Student already exists"});
    }
    //confirm password
    if(req.body.password!==req.body.confirmPassword)
    {
       res.json({message:"passwords doesnt match"});
    }
  try{
    const salt= await bcrypt.genSalt(7);
    const hashPassword= await bcrypt.hash(req.body.password,salt);


    //store
    const studentInput={
        name:req.body.name,
        email:req.body.email,
        password:hashPassword,
        studentID:req.body.studentID,
        dob:req.body.dob,
        phone:req.body.phone,
        year:req.body.year
    };
    const newStudent = new Students(studentInput);
    newStudent.save().then(data=>{
        res.json(data);
    });
}catch(err){
    return res.json(err);
}
});

router.post("/login",async(req,res)=>
  {
      const {error}=loginVal(req.body);
      if(error){
          return res.json(error);
      }
      const studentExist= await Students.findOne({
          email:req.body.email
      });
      if(!studentExist)
      {
          return false;
      }
      
      //password matching
      const varified = await bcrypt.compare(req.body.password,studentExist.password);
      if(!varified)
      {
          return false;
      }
      return res.json(studentExist);
      
  })
module.exports=router;