const express= require("express");
const router= express.Router();
const Classes= require('../Models/classModel');
const {classRegisterVal} = require('../validation');
router.get('/get',async(req,res)=>
{
    Classes.find().then(data=>{
        res.json(data);
    })
});
router.post('/register',async(req,res)=>
{
    const {error}=classRegisterVal(req.body);
    if(error){
        return res.json(error);
    }
    const classInput={
        subject:req.body.subject,
        year:req.body.year
    };
    const newClass = new Classes(classInput);
    newClass.save().then(data=>{
        res.json(data);
    });
});
module.exports=router;