const express= require("express");
const router= express.Router();
const Facultys= require('../Models/FacultyModel');
const {facultyVal,loginVal} = require('../validation');
router.get('/get',async(req,res)=>
{
    Facultys.find().then(data=>{
        res.json(data);
    })
});
router.post('/register',async(req,res)=>
{
    const {error}=facultyVal(req.body);
    if(error){
        return res.json(error);
    }
    //Teacher exists
    const facultyExist= await Facultys.findOne({email:req.body.email});
    if(facultyExist)
    {
        return res.json({message:"Faculty already exists"});
    }
    //confirm password
    if(req.body.password!==req.body.confirmPassword)
    {
       res.json({message:"passwords doesnt match"});
    }
try{
    const salt= await bcrypt.genSalt(7);
    const hashPassword= await bcrypt.hash(req.body.password,salt);


    //storeteacherin database
    const facultyInput={
        name:req.body.name,
        email:req.body.email,
        password:hashPassword,
        dob:req.body.dob,
        phone:req.body.phone,
        classID:req.body.classID,
        subject:req.body.subject
    };
    const newFaculty = new Facultys(facultyInput);
    newFaculty.save().then(data=>{
        res.json(data);
    });
}catch(err){
    return res.json(err);
}
});

router.post("/login",async(req,res)=>
  {
      const {error}=loginVal(req.body);
      if(error){
          return res.json(error);
      }
      const facultyExist= await Facultys.findOne({
          email:req.body.email
      });
      if(!facultyExist)
      {
          return false;
      }
      
      //password matching
      const varified = await bcrypt.compare(req.body.password,facultyExist.password);
      if(!varified)
      {
          return false;
      }
      return res.json(facultyExist);
      
  })
module.exports=router;