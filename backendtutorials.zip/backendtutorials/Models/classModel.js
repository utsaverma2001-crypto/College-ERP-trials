const mongoose= require("mongoose");
const schema = mongoose.Schema;

const classSchema= new schema(
    {
        subject:{type:String,required:true},
        year:{type:Number,required:true},
    }
);
module.exports = mongoose.model("Class",classSchema);