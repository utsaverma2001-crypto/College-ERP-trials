const mongoose= require("mongoose");
const schema = mongoose.Schema;

const studentSchema= new schema(
    {
        _id:false,
        name:{type:String,required:true},
        email:{type:String,required:true},
        password:{type:String,required:true},
        studentID:{type:String,required:true},
        dob:{type:String},
        phone:{type:Number},
        year:{type:Number,required:true}
    }
);
module.exports = mongoose.model("Student",studentSchema);