const mongoose= require("mongoose");
const schema = mongoose.Schema;

const FacultySchema= new schema(
    {
        name:{type:String,required:true},
        email:{type:String,required:true},
        password:{type:String,required:true},
        dob:{type:String},
        phone:{type:Number},
        classID:{type:String,required:true},
        subject:{type:String,required:true}
    }
);
module.exports = mongoose.model("Faculty",FacultySchema);