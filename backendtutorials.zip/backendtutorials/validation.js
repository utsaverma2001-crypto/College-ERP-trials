const Joi = require("@hapi/joi");
const registerVal=(data)=>{
    const schema= Joi.object({
        name:Joi.string().min(10).required(),
        email:Joi.string().required().email(),
        password:Joi.string().min(8).required(),
        confirmPassword:Joi.string().min(8).required(),
        dob:Joi.string(),
        phone:Joi.number(),
    })
    return schema.validate(data)
}
const studentVal=(data)=>{
    const schema= Joi.object({
        name:Joi.string().min(10).required(),
        email:Joi.string().required().email(),
        password:Joi.string().min(8).required(),
        confirmPassword:Joi.string().min(8).required(),
        studentID:Joi.string().required(),
        dob:Joi.string(),
        phone:Joi.number(),
        year:Joi.number().required().min(4)
    })
    return schema.validate(data)
}
const facultyVal=(data)=>{
    const schema= Joi.object({
        name:Joi.string().min(10).required(),
        email:Joi.string().required().email(),
        password:Joi.string().min(8).required(),
        confirmPassword:Joi.string().min(8).required(),
        dob:Joi.string(),
        phone:Joi.number(),
        classID:Joi.string().required(),
        subject:Joi.string().required()
    })
    return schema.validate(data)
}

const classRegisterVal=(data)=>{
    const schema= Joi.object({
        subject:Joi.string().required(),
        year:Joi.number().min(8).required()
    })
    return schema.validate(data)
}
const loginVal =(data)=>{
    const schema= Joi.object({
        email:Joi.string().required().email(),
        password:Joi.string().min(8).required()
    })
    return schema.validate(data)
}
module.exports.registerVal = registerVal;
module.exports.loginVal = loginVal;
module.exports.classRegisterVal = classRegisterVal;
module.exports.facultyVal = facultyVal;
module.exports.studentVal = studentVal;