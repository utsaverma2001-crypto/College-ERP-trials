import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import {Route , Switch } from 'react-router-dom';
import './App.css';
import LoginNavbar from './LoginNavbar';
import StudentLogin from './StudentLogin';
import AdminLogin from './Admin/AdminLogin';
import FacultyLogin from './FacultyLogin';

function App() {
  return (
    <div className="App">
      <div className="first-navbar">
        <LoginNavbar/>
        <Switch>
          <Route exact path="/Admin/AdminLogin" component={AdminLogin} />
          <Route exact path="/StudentLogin" component={StudentLogin} />
          <Route exact path="/FacultyLogin" component={FacultyLogin} />
        </Switch>
      </div>
    </div>
  );
}

export default App;
