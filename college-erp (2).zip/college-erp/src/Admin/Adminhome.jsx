import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import AdminNavbar from './AdminNavbar';
import {Router, Route , Switch} from 'react-router-dom';
import AddFaculty from './AddFaculty';
import AddSubject from './AddSubject';
import AddStudent from './AddStudent';
import AddAdmin from './AddAdmin';
import OurFaculties from './OurFaculties';
import OurStudents from './OurStudents';
import Subjects from './Subjects';
import './Adminhome.css';



function Adminhome() {
  
    return (
        <div className="admin-home">
        <div className="admin-home-navbar">
          <AdminNavbar />
          <Router>
          <Switch>
            <Route exact path="/AddFaculty" component={AddFaculty} />
            <Route exact path="/AddStudent" component={AddStudent} />
            <Route exact path="/AddSubject" component={AddSubject} />
            <Route exact path="/AddAdmin" component={AddAdmin} />
            <Route exact path="/OurFaculties" component={OurFaculties} />
            <Route exact path="/OurStudents" component={OurStudents} />
            <Route exact path="/Subjects" component={Subjects} />
          </Switch>
          </Router>
        </div>
        <div className="admin-details">
        <table>
            <tr>
              <th>Name</th>
              <th>DOB</th>
              <th>Phone</th>
            </tr>
            <tr>
              <td>Vivek</td>
              <td>sherkhan</td>
              <td>gaand fat gayi</td>
            </tr>
            </table>
        </div>
        </div>
    )
}

export default Adminhome
