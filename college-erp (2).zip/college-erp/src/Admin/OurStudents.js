import React from 'react'

function OurStudents() {
    return (
        <div>
            <h1>This is our students</h1>
        </div>
    )
}

export default OurStudents
