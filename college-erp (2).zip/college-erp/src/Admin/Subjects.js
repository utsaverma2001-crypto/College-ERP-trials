import React from 'react'

function Subjects() {
    return (
        <div>
            <h1>This is subjects</h1>
        </div>
    )
}

export default Subjects
