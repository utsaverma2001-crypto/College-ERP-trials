import React from 'react'

function AddAdmin() {
    return (
        <div>
            <h1>This is Add Admin</h1>
        </div>
    )
}

export default AddAdmin
