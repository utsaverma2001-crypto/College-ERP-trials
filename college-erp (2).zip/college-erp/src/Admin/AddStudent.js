import React from 'react'

function AddStudent() {
    return (
        <div>
            <h1>This is Add Student</h1>
        </div>
    )
}

export default AddStudent;
