import React, { useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button'
import '../login-form.css';
// import { useHistory } from "react-router-dom";
//import Admins from '../backend/adminModel';
import Adminhome from './Adminhome';




function AdminLogin() {

    // const history = useHistory();



    const [Email, setEmail] =useState("");
    const [password, setPassword] = useState("");

    const handleEmail = (e)=>{
        let Email = e.target.value
        setEmail(Email);
    }

    const handlePassword = (e)=>{
        let password = e.target.value
        setPassword(password);
    }




     function handleSubmit(event) {
        event.preventDefault();
        // history.push("/Adminhome");

        <Adminhome  />

        // const Findadmin = Admins.findOne({email : Email});
        // if(Findadmin){
        //     if(password === Findadmin.password)
        //     <Adminhome res_obj= {Findadmin} />
        // } 

    //     const registered={
    //         email:email,
    //         password:password
      
        // try {
        //    await Auth.signIn(email, password);
        //   userHasAuthenticated(true);
        
        // } catch (e) {
        //   alert(e.message);
        // }
      }

    
    return (
        <div className="login-form" >
        <h3 classname="login-title">ADMIN</h3>

            <Form onSubmit={handleSubmit}>
                <Form.Group controlId="formBasicEmail">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control name="email" size="md" type="email" onChange={handleEmail} placeholder="Enter email"  value={Email} />
                </Form.Group>

                <Form.Group controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control name= "password" size="md" type="password"  onChange={handlePassword} placeholder="Password"  value={password} />
                </Form.Group>
                <Button variant="primary" type="submit">
                    Login
                </Button>
            </Form>
        </div>
    )
}

export default AdminLogin
