import React from 'react'

function AddFaculty() {
    return (
        <div>
            <h1>This is Add Faculty</h1>
        </div>
    )
}

export default AddFaculty;
