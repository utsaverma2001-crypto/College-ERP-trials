import React from 'react'

function OurFaculties() {
    return (
        <div>
            <h1>This is our Faculties</h1>
        </div>
    )
}

export default OurFaculties
