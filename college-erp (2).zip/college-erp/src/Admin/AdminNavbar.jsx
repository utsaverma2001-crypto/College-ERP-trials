import React from 'react';
import {Link } from 'react-router-dom';
import './Adminhome.css';

function AdminNavbar() {
    return (
        <div className="admin-home-navbar">
            <Link to="/AddFaculty"   className="admin-navbar-text">ADD FACULTY</Link>
            <Link to="/AddStudent" className="admin-navbar-text">ADD STUDENT</Link>
            <Link to="/AddSubject" className="admin-navbar-text">ADD SUBJECT</Link>
            <Link to="/AddAdmin" className="admin-navbar-text">ADD ADMIN</Link>
            <Link to="/OurFaculties" className="admin-navbar-text">OUR FACULTIES</Link>
            <Link to="/OurStudents" className="admin-navbar-text">OUR STUDENTS</Link>
            <Link to="/Subjects" className="admin-navbar-text">SUBJECTS</Link>
        </div>
    )
}

export default AdminNavbar;