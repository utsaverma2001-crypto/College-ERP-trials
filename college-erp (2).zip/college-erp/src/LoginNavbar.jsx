import React from 'react';
import {Link } from 'react-router-dom';
import './Login-Navbar.css';

function LoginNavbar() {
    return (
        <div className="login-navbar">
            <Link to="/Admin/AdminLogin"   className="login-navbar-text">Admin</Link>
            <Link to="/StudentLogin" className="login-navbar-text">Student</Link>
            <Link to="/FacultyLogin" className="login-navbar-text">Faculty</Link>
        </div>
    )
}

export default LoginNavbar;
