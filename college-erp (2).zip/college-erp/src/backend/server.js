const express= require ("express");
const app= express();
const mongoose = require("mongoose");

app.use(express.json());
mongoose.connect("mongodb+srv://utsaverma:Up11x4854$@cluster0.d9kko.mongodb.net/Cluster10?retryWrites=true&w=majority",{useNewUrlParser:true, useUnifiedTopology:true},()=>
{
    console.log("connected to database");
});

//Admin Routes
const adminRoutes=require('./adminRoute');
app.use("/admin",adminRoutes);

// //Teacher Routes
// const facultyRoutes=require('./Routes/FacultyRoute');
// app.use("/faculty",facultyRoutes);

// //Student Routes
// const studentRoutes=require('./Routes/studentRoute');
// app.use("/student",studentRoutes);

// //Class Routes
// const classRoutes=require('./Routes/classRoute');
// app.use("/class",classRoutes);

// //404 error handling
// app.all('*',(req,res)=>{
//     return res.status(404).json({message:"page not found"});
// })

app.listen(5000,()=> {
    console.log("server connected");
});
